import torch
import torch.nn as nn
import torchvision


class ImageEncoder(nn.Module):
    def __init__(self, args):
        super(ImageEncoder, self).__init__()
        self.args = args

        model = torchvision.models.resnet18(pretrained=True)
        modules = list(model.children())[:-1]
        self.model = nn.Sequential(*modules)

        pool_func = (
            nn.AdaptiveAvgPool2d
            if args.img_embed_pool_type == "avg"
            else nn.AdaptiveMaxPool2d
        )

        if args.num_image_embeds in [1, 2, 3, 5, 7]:
            self.pool = pool_func((args.num_image_embeds, 1))
        elif args.num_image_embeds == 4:
            self.pool = pool_func((2, 2))
        elif args.num_image_embeds == 6:
            self.pool = pool_func((3, 2))
        elif args.num_image_embeds == 8:
            self.pool = pool_func((4, 2))
        elif args.num_image_embeds == 9:
            self.pool = pool_func((3, 3))

    def forward(self, x):
        # Bx3x224x224 -> Bx2048x7x7 -> Bx2048xN -> BxNx2048
        out = self.model(x)
        out = self.pool(out)
        out = torch.flatten(out, start_dim=2)
        out = out.transpose(1, 2).contiguous()
        return out  # BxNx2048
# class ImageEncoder(nn.Module):
#     def __init__(self):
#         super(ImageEncoder, self).__init__()
#
#         model = torchvision.models.resnet18(pretrained=True)
#         modules = list(model.children())[:-1]
#         self.model = nn.Sequential(*modules)
#
#         self.pool = nn.AdaptiveAvgPool2d((1, 1))
#
#     def forward(self, x):
#         # Bx3x224x224 -> Bx2048x7x7 -> Bx2048x1x1 -> Bx2048x1 -> Bx1x2048
#         out = self.model(x)
#         out = self.pool(out)
#         out = torch.flatten(out, start_dim=2)
#         out = out.transpose(1, 2).contiguous()
#         return out  # Bx1x2048
